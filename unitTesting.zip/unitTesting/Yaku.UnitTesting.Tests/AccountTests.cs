﻿using NUnit.Framework;

namespace Yaku.UnitTesting.Tests
{
    [TestFixture]
    public class AccountTests
    {
        [Test]
        public void ShouldSubstractTheWithdrawalFromCurrentBalance()
        {
            // arrange  
            double currentBalance = 1000;
            double withdrawal = 150;
            double expectedBalance = 850;
            var account = new Account()
            {
                Number = 41113000,
                Balance = currentBalance
            };

            // act 
            account.Withdraw(withdrawal);
            double actualBalance = account.Balance;
            // assert  
            Assert.AreEqual(expectedBalance, actualBalance);
        }
    }

}

﻿namespace Yaku.UnitTesting
{
    public class Account
    {
        public Account()
        {
        }

        public int Number { get; set; }
        public double Balance { get; set; }

        public void Withdraw(double amount)
        {
            Balance -= amount;
        }
    }
}

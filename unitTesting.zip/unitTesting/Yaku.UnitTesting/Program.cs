﻿using System;

namespace Yaku.UnitTesting
{
    public class Program
    {
        
        static void Main(string[] args)
        {
            const double withdrawal = 350.66;
            const double initialBalance = 5609.4;
            const int accountNumber = 333444;
            Console.WriteLine($"Initial Balance = {initialBalance}, Withdrawal Amount: {withdrawal}. Press any key to proceed...");
            Console.ReadKey();
            var account = new Account { Balance = initialBalance, Number = accountNumber };
            Console.WriteLine($"Balance before withdrawal: {account.Balance}");
            account.Withdraw(withdrawal);
            Console.WriteLine($"Balance before withdrawal: {account.Balance}");
            Console.ReadLine();

        }
    }
}
